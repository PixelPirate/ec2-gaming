#!/bin/sh

pkill -P `cat /var/run/openvpnup.pid`